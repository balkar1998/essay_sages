<html>
    <head>
    <meta charset="utf-8">
    </head>
    <body>
        <h2>Hi Welcome To Essay Sages</h2>
        <p>Essay Sages is a united states education technology site company based in San Fransisco, California which operates an online learning platform for students and tutors founded in 2009.</p>
        <footer>
            <p>New York, NY 10012, US</p>
            <p>info@example.com</p>
            <p>+ 01 234 567 88</p>
            <p>+ 01 234 567 89</p>
        </footer>
    </body>
</html>
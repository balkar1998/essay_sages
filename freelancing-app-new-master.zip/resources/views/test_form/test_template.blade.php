<html>
    <head>
    <meta charset="utf-8">
    </head>
    <body>
        <h2>Hi Welcome To Essay Sages</h2>
        <p>Proficiency Test For Enrollment</p>
        <a href="http://127.0.0.1:8000/proficiency_test">Access Page</a>

    </body>
</html>